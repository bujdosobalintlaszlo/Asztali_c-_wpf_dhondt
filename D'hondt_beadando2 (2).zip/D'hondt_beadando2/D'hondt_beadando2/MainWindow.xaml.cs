﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System;
using Microsoft.Win32;
using System.Windows;
using System.IO;
using C1.WPF.Chart;
using System.Diagnostics;

namespace D_hondt_beadando2
{
    public partial class MainWindow : Window
    {
        private string hasznaltFile = "";
        public MainWindow()
        {
            InitializeComponent();
            lfilenev.Text = "Üres";
        }
        public void btorol_Click(object sender, RoutedEventArgs e)
        {

        }

        void bfileMegnyit_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Text files (*.txt)|*.txt";

            if (ofd.ShowDialog() == true)
            {
                lfilenev.Text = ofd.SafeFileName;
                hasznaltFile = ofd.FileName;
                bgeneralas.IsEnabled = false;
                bfileMegnyit.IsEnabled = false;
                btorol.IsEnabled = true;
                bment.IsEnabled = true;
                ElemekMegJelenit();
            }
            else
            {
                lfilenev.Text = "Hibás file";
            }
        }
        void ElemekMegJelenit()
        {
            Szimulacio sz = new Szimulacio(hasznaltFile);
            if (sz.Ellenoriz())
            {
                sz.MatrixGen(matrix);
                
                lszavazatszam.Content = sz.SzavazatSzam();
                lnemszav.Content = sz.Nemszav();
                lmandszam.Content = sz.MandSzam();
                lpartszam.Content = sz.Partszam();
                lnyertpart.Content = sz.NyertNev();
                lnyertszavszam.Content = sz.NyertSzavSzam();
                lnyertszavarany.Content = sz.NyertSzavArany() + "%";
                sz.SzavazatiAranyDiagram(szavazatosdiag);
                sz.MandatumAranyDiagram(mandatumosdiag);
                sz.SzavazatokEsPartok(szavazatoszldiag);
            }
            else
            {
                lfilenev.Text = "Hibás file!";
                lfilenev.Foreground = new SolidColorBrush(Colors.Red);
            }
        }
        void Ment(object sender, RoutedEventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Text files (*.txt)|*.txt";
            if (sfd.ShowDialog() == true)
            {
                if (File.Exists(sfd.FileName))
                {
                    string ujFajlNev = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(sfd.FileName), System.IO.Path.GetFileNameWithoutExtension(sfd.FileName) + "_duplikalt.txt");
                    File.Copy(hasznaltFile, ujFajlNev);
                }
                else
                {
                    File.Copy(hasznaltFile, sfd.FileName);
                }
            }
        }

        void Torol(object sender, RoutedEventArgs e) {
            lfilenev.Text = "Üres";
            lszavazatszam.Content = "0";
            lnemszav.Content = "0";
            lmandszam.Content = "0";
            lpartszam.Content = "0";
            lnyertpart.Content = "-";
            lnyertszavszam.Content = "0";
            lnyertszavarany.Content = "0";
            hasznaltFile = "";
        }

        private void bgeneralas_Click(object sender, RoutedEventArgs e)
        {
            // Create a DockPanel
            DockPanel dpGen = new DockPanel();
            dpGen.Height = this.Height;
            dpGen.Width = this.Width;
            dpGen.Background = Brushes.Black; // Set background color to black
            dpGen.Height = 1000;
            dpGen.Width = this.ActualWidth;
            // Create Labels
            Label lszavszam = new Label();
            lszavszam.Content = "Emberek száma:";
            lszavszam.FontSize = 20;
            lszavszam.Foreground = Brushes.White; // Set font color to white
            DockPanel.SetDock(lszavszam, Dock.Top);

            Label lnemszav = new Label();
            lnemszav.Content = "Nem szavazók száma:";
            lnemszav.FontSize = 20;
            lnemszav.Foreground = Brushes.White;
            DockPanel.SetDock(lnemszav, Dock.Top);

            Label lmandatumszam = new Label();
            lmandatumszam.Content = "Mandátumok száma:";
            lmandatumszam.FontSize = 20;
            lmandatumszam.Foreground = Brushes.White;
            DockPanel.SetDock(lmandatumszam, Dock.Top);

            Label lmapartszam = new Label();
            lmapartszam.Content = "Pártok száma:";
            lmapartszam.FontSize = 20;
            lmapartszam.Foreground = Brushes.White;
            DockPanel.SetDock(lmapartszam, Dock.Top);

            // Create TextBoxes or other controls for numeric input
            TextBox txtSzavszam = new TextBox();
            txtSzavszam.FontSize = 20;
            DockPanel.SetDock(txtSzavszam, Dock.Top);

            TextBox txtNemszav = new TextBox();
            txtNemszav.FontSize = 20;
            DockPanel.SetDock(txtNemszav, Dock.Top);

            TextBox txtMandatumszam = new TextBox();
            txtMandatumszam.FontSize = 20;
            DockPanel.SetDock(txtMandatumszam, Dock.Top);

            TextBox txtPartszam = new TextBox();
            txtPartszam.FontSize = 20;
            DockPanel.SetDock(txtPartszam, Dock.Top);

            // Add controls to the DockPanel
            dpGen.Children.Add(lszavszam);
            dpGen.Children.Add(txtSzavszam);
            dpGen.Children.Add(lnemszav);
            dpGen.Children.Add(txtNemszav);
            dpGen.Children.Add(lmandatumszam);
            dpGen.Children.Add(txtMandatumszam);
            dpGen.Children.Add(lmapartszam);
            dpGen.Children.Add(txtPartszam);

            // Add DockPanel to the Grid
            Grid.SetRow(dpGen, 0);
            Grid.SetColumn(dpGen, 0);
            Main.Children.Add(dpGen); // Replace "gridName" with the name of your Grid element
        }


        void Gen(object o, EventArgs e)
        {
            /*
            Szimulacio sz = new Szimulacio("gen.txt");
            sz.General(int.Parse(numapartszam.Value.ToString()), int.Parse(numandatumszam.Value.ToString()), int.Parse(nunemszav.Value.ToString()), int.Parse(nuszavszam.Value.ToString()));
            lszavazatszam.Text = sz.SzavazatSzam();
            lmandatumszam.Text = sz.MandSzam();
            lnyertmandarany.Text = sz.NyertMandArany() + "%";
            lnyertesnev.Text = sz.NyertNev();
            lpartokszama.Text = sz.Partszam();
            lnyertszavszam.Text = sz.NyertSzavSzam();
            lnemszavazott.Text = sz.Nemszav();
            sz.MandatumAranyDiagram(cmandatumok);
            sz.SzavazatiAranyDiagram(cszavaranydiag);
            sz.SzavazatokEsPartok(cszavazatespart);
            sz.SecondRun(dgvmatrix);
            btorol.Enabled = true;
            bok.Enabled = false;
            bgeneral.Enabled = false;
            bfilekivalaszt.Enabled = false;
            pBeallitasok.Dispose();
            */
        }




    }
}