﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Dhondt_wpf_vegleges
{
    /// <summary>
    /// Interaction logic for Generalas.xaml
    /// </summary>
    public partial class Generalas : Window
    {
        int genmandatumszam;
        int gennemszav;
        int genandszam;
        int genpartszam;
        public int Genmandatumszam { get {
                return genmandatumszam;
            } 
        }
        public int Gennemszav
        {
            get
            {
                return gennemszav;
            }
        }
        public int Genemberszam
        {
            get
            {
                return genandszam;
            }
        }
        public int Genpartszam
        {
            get
            {
                return genpartszam;
            }
        }


        public Generalas()
        {
            InitializeComponent();
        }

        private void Adatbekuld(object sender, RoutedEventArgs e)
        {
            genmandatumszam = int.Parse(mandszam.Text);
            gennemszav = int.Parse(nemszav.Text);
            genandszam = int.Parse(emberszam.Text);
            genpartszam = int.Parse(partszam.Text);
            this.DialogResult = true;
            this.Close();
        }

    }
}
