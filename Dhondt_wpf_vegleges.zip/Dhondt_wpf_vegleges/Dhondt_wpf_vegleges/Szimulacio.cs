﻿using C1.Chart;
using C1.WPF.Chart;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Media3D;


namespace Dhondt_wpf_vegleges
{
    internal class Szimulacio
    {
        private int nemszav = 0;
        private string filepath;
        private static Random r = new Random();
        private char[] abc = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();
        private string[] szazalek = new string[3] { "5", "10", "15" };
        Szamol sz;
        //konstruktor
        public Szimulacio(string filepath)
        {
            this.filepath = filepath;
            sz = new Szamol(filepath);
        }

        // Fájl feldolgozás metódus
        public void Feldolgoz()
        {
            sz = new Szamol(filepath);
        }

        public bool Ellenoriz() => File.ReadLines(filepath).Count() - 1 <= 15;
        private Dictionary<string, int> MandatumCount(List<(int, string)> k) => k.GroupBy(item => item.Item2).ToDictionary(group => group.Key, group => group.Count());

        public void MatrixGen(DataGrid dgv)
        {
            Szamol sz = new Szamol(filepath);
            sz.Atfordit();
            SecondTablaKiir(dgv, sz.p);
        }

        public void SecondTablaKiir(DataGrid dataGridView, Partok p)
        {
            dataGridView.Items.Clear();
            dataGridView.Items.Refresh();
            List<(int, string)> k = sz.Cserelget();
            int n = MandatumCount(k).Sum(x => x.Value);
            dataGridView.ItemsSource = null;
            dataGridView.Columns.Clear();
            dataGridView.AutoGenerateColumns = false;
            dataGridView.RowHeight = (dataGridView.ActualHeight - 30) / sz.p.Partszam;
            dataGridView.VerticalAlignment = System.Windows.VerticalAlignment.Center;
            dataGridView.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;

            for (int i = 0; i < n + 1; i++)
            {
                dataGridView.Columns.Add(new DataGridTextColumn
                {
                    Header = i == 0 ? "" : $"{i}.",
                    Binding = new System.Windows.Data.Binding($"[{i}]"),
                    Width = new DataGridLength(1, DataGridLengthUnitType.Star)
                });
            }

            foreach (var part in p.Parts)
            {
                List<object> rowData = new List<object> { part.PartNev };

                foreach (var elem in part.oszlop)
                {
                    rowData.Add(elem.Item1);
                }

                dataGridView.Items.Add(rowData);
            }

            dataGridView.Loaded += (sender, e) =>
            {
                UpdateRowHeights(dataGridView, p.Partszam);
            };


            dataGridView.SizeChanged += (sender, e) =>
            {
                for (int i = 0; i < dataGridView.Columns.Count; ++i)
                {
                    dataGridView.Columns[i].Width = new DataGridLength(1, DataGridLengthUnitType.Star);

                }

            };
            foreach (var part in p.Parts)
            {
                List<object> rowData = new List<object> { part.PartNev };

                foreach (var elem in part.oszlop)
                {
                    rowData.Add(elem.Item1);
                }

            }
            dataGridView.KeyDown += dataGridView_KeyDown;
            
        }

        private void UpdateRowHeights(DataGrid dataGridView, int totalRows)
        {
            if (totalRows == 0)
                return;

            double rowHeight = (dataGridView.ActualHeight - 13) / totalRows - 1;
            if (rowHeight < 0)
                rowHeight = 0;

            for (int i = 0; i < dataGridView.Items.Count; i++)
            {
                DataGridRow row = (DataGridRow)dataGridView.ItemContainerGenerator.ContainerFromIndex(i);
                if (row != null)
                {
                    row.Height = rowHeight;
                }
            }
        }

        private void dataGridView_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Up || e.Key == Key.Down || e.Key == Key.Left || e.Key == Key.Right)
            {
                e.Handled = true;
            }
        }

        public string SzavazatSzam() => sz.p.Parts.Sum(x => x.SzavazatSzam).ToString();

        public string MandSzam() => MandatumCount(sz.Cserelget()).Sum(x => x.Value).ToString();

        public string NyertSzavArany() => Math.Round(double.Parse(NyertSzavSzam()) / sz.p.Parts.Sum(x => x.SzavazatSzam) * 100, 2).ToString();

        public string Partszam() => sz.p.Partszam.ToString();

        public string NyertNev()
        {
            List<(int, string)> k = sz.Cserelget();
            int maxInt = k.Max(tuple => tuple.Item1);
            var maxTuple = k.First(tuple => tuple.Item1 == maxInt);
            return maxTuple.Item2;
        }
        public string NyertSzavSzam() => sz.p.Parts.Max(x => x.SzavazatSzam).ToString();

        public string Nemszav() => sz.p.nemszavazott.ToString();

        
        public void General(int partszam, int mandatumszam, int nemszavazott, int szavazokszama)
        {
            int nullaz = 0;
            int min = 0;
            int max = (int)(szavazokszama * 0.75);
            StreamWriter w = new StreamWriter("gen.txt");
            w.WriteLine($"{mandatumszam},{nemszavazott}");
            for (int i = 0; i < partszam; ++i)
            {
                if (i != partszam - 1)
                {
                    if (nullaz < 2)
                    {
                        if (r.Next(0, 16) == 1)
                        {
                            w.WriteLine(string.Concat("Part", abc[i], " ", r.Next(0, 2), " ", 0, " ", szazalek[r.Next(0, 3)]));
                            nullaz++;
                        }
                        else
                        {
                            int szavazata = szavazokszama - r.Next(min, max);
                            szavazokszama -= szavazata;
                            max = (int)(szavazokszama * 0.9);
                            w.WriteLine(string.Concat("Part", abc[i], " ", r.Next(0, 2), " ", szavazata, " ", szazalek[r.Next(0, 3)]));
                        }
                    }
                    else
                    {
                        int szavazata = szavazokszama - r.Next(min, max);
                        szavazokszama -= szavazata;
                        max = (int)(szavazokszama * 0.9);
                        w.WriteLine(string.Concat("Part", abc[i], " ", r.Next(0, 2), " ", szavazata, " ", szazalek[r.Next(0, 3)]));

                    }
                }
                else
                {
                    w.WriteLine(string.Concat("Part", abc[i], " ", r.Next(0, 2), " ", szavazokszama, " ", szazalek[r.Next(0, 3)]));
                }
            }
            w.Close();
        }
       

        public void MandatumAranyDiagram(FlexPie f)
        {
            List<(int, string)> m = sz.MandatumKioszt().GroupBy(x => x.Item2).Select(group => (group.Sum(x => x.Item1), group.Key)).ToList();
            FlexPieSliceCollection szeletek = new FlexPieSliceCollection();
            m.ForEach(x => {
                FlexPieSlice szelet = new FlexPieSlice();
                szelet.Name = x.Item2;
                szelet.Value = x.Item1;
                szeletek.Add(szelet);
            });
            f.ItemsSource = szeletek;
        }


        public void SzavazatiAranyDiagram(FlexPie f)
        {
            FlexPieSliceCollection szeletek = new FlexPieSliceCollection();
            sz.p.Parts.ForEach(part => {
                FlexPieSlice szelet = new FlexPieSlice();
                szelet.Name = part.PartNev;
                szelet.Value = part.SzavazatSzam;
                szeletek.Add(szelet);
            });
            f.ItemsSource = szeletek;
        }

        public void SzavazatokEsPartok(FlexChart c)
        {
            c.Series.Clear();
            Series series = new Series();
            series.ChartType = ChartType.Column;
            for (int i = 0; i < sz.p.Parts.Count; ++i)
            {
                series.Binding = "SzavazatSzam";
                series.BindingX = "PartNev";
                series.ItemsSource = sz.p.Parts;
            }
            c.Series.Add(series);
        }
    }
}
