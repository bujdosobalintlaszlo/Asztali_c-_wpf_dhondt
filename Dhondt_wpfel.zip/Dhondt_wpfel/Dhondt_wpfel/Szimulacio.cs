﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Data;
using System.Drawing;
using System.Reflection;
using static System.Net.WebRequestMethods;
using System.Xml.Linq;

namespace Dhondt
{
    /// <summary>
    /// 
    /// </summary>
    class Szimulacio
    {

        private int nemszav = 0;
        private string filepath;
        private static Random r = new Random();
        private char[] abc = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();
        private string[] szazalek = new string[3] { "5", "10", "15" };

        //konstruktor
        public Szimulacio(string filepath)
        {
            this.filepath = filepath;
        }

        public bool Ellenoriz() => System.IO.File.ReadLines(filepath).Count() - 1 <= 15;
    }



}